﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Linq;
using System.Xml.XPath;
using Trisoft.InfoShare.Plugins.SDK;
using Trisoft.InfoShare.Plugins.SDK.Publish.PostProcess;
using Trisoft.InfoShare.Plugins.SDK.Publish;
using System.Threading;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    /// <summary>
    /// Custom plugin that will be triggered as part of the publish process
    /// Rename the Export to the correct Name
    /// </summary>
    // This attribute is used to make the class discoverable by the plugin engine.
    [Export("$safeprojectname$", typeof(IPublishPostProcessPlugin))]
    [PartCreationPolicy(CreationPolicy.NonShared)]
    public class $safeprojectname$ : IPublishPostProcessPlugin
    {
        #region Private constants       
        /// <summary>
        /// Check every x files whether the publication output was not cancelled
        /// </summary>
        public static readonly long CheckForCancelledBatchSize = 1000;
        #endregion

        #region Private fields
        /// <summary>
        /// The configuration that is set in the Publish Plugin Setting
        /// </summary>
        private IPluginConfiguration _configuration;
        /// <summary>
        /// The name of the xml element of which to extract the parameter
        /// </summary>
        private string ParameterName;
        /// <summary>
        /// The name to set in the variableName for the extract text
        /// </summary>
        private string _variableName;
        /// <summary>
        /// Authentication Context to communicate with the application.
        /// Setting it to empty to make sure we have a fresh authentication
        /// </summary>
        private IPublishPostProcessContext _context = null;
        /// <summary>
        /// Progress ID to use for the EventMonitor.
        /// Setting it to zero to make sure we have a new ID
        /// </summary>
        private long _progressId = 0;
        /// <summary>
        /// Initialize the LogService. This will export any log message to the logfile on the filesystem
        /// Setting it to empty to make sure we have a fresh log service
        /// </summary>
        private ILogService _logService = null;
        /// <summary>
        /// Initialize the EventMonitor. This will export any log message to the eventlog in the webclient.
        /// Setting it to empty to make sure we have a fresh event logservice
        /// </summary>
        private IEventMonitor _eventMonitor = null;

        #endregion

        #region Public properties
       
        public string Name { get; set; }
        #endregion

        

        public void Initialize(IPluginConfiguration configuration)
        {
            _configuration = configuration;
            _logService = _configuration.LogService;
            //Read the value of a configuration parameter as defined in the XML Publish Plugin Setting
            configuration.Parameters.TryGetValue(ParameterName, out _variableName);          
            
        }

        /// <summary>
        /// This method will be called by the engine as part of a main action        
        /// </summary>
        /// <param name="context"></param>
        public void Run(IPublishPostProcessContext context)
        {
            _context = context;
            _eventMonitor = _context.EventMonitor;
            _progressId = _context.ProgressId;

            //Starting a new logger function that will log to both the eventlog (when available) and a logfile
            Helpers.Logger myLogger = new Helpers.Logger(_eventMonitor, _progressId, _logService);
            //Creating a new Cancell Token
            CancellationTokenSource cts = new CancellationTokenSource();
            // Use ParallelOptions instance to store the CancellationToken
            ParallelOptions parallelOptions = new ParallelOptions();
            parallelOptions.CancellationToken = cts.Token;

            myLogger.writeInfo(string.Format("{0} started", Name), string.Format("PublishPostProcess plugin {0} started.", Name));


            //This section is sample code
            //Getting Publication Metadata
            IMetadataProvider _metadataProvider = context.MetadataFileLoader(context.PublicationOutputMetadataFile);
            //Retrieving the Metadata Value
            //Using Publication Title as sample
            string pubTitle = string.Empty;
            if (_metadataProvider.IsFieldAvailable("FTITLE", IshLevel.Logical))
            {
                pubTitle = _metadataProvider.GetFieldValueAsString("FTITLE", IshLevel.Logical);
            }

           

            try
            {
                //Do something for each requested language in the publication
                foreach (IPublishSingleLanguageReportItems languageReportItem in _context.ReportItems)
                {
                    //checking if te user has cancelled the publish job
                    if (_context.IsCancelled())
                    {
                        myLogger.writeInfo("Publish was cancelled by the user", string.Format("Executing of plugin {0} aborted as the user has cancelled the publication",Name));                        
                        cts.Cancel();
                        parallelOptions.CancellationToken.ThrowIfCancellationRequested();
                    }
                    //Execute your code for each Language

                    // Doing something for each object in one of the requested language
                    foreach (IPublishReportItem reportItem in languageReportItem.List(PublishItemMode.PrimaryItem))
                    {
                        //Execute your code for each version

                        //Sample to retrieve the root document  metadata
                        
                        string mapTitle = string.Empty;
                        string translator = string.Empty;
                        _metadataProvider = context.MetadataFileLoader(new FileInfo(Path.Combine(languageReportItem.LanguageDirectory.FullName, Path.ChangeExtension(context.RootDocumentObjectFile.Name,"met"))));
                        if (_metadataProvider.IsFieldAvailable("FTITLE", IshLevel.Logical))
                        {
                            mapTitle = _metadataProvider.GetFieldValueAsString("FTITLE", IshLevel.Logical);                           
                        }
                        if (_metadataProvider.IsFieldAvailable("FTRANSLATOR", IshLevel.Logical))
                        {
                            translator = _metadataProvider.GetFieldValueAsString("FTRANSLATOR", IshLevel.Language);
                        }

                    }
                }
            }

            catch (OperationCanceledException)
            {
                cts.Cancel();
                // Publication Output is cancelled detected by one of the threads
                throw new Exceptions.CustomUserCancelException();
            }
            catch (Exception ex)
            {
                myLogger.writeWarning(string.Format("Execution of Plugin {0} failed", Name), string.Format("Execution of Plugin {0} Failed. {1}", Name, ex));                
                cts.Cancel();
                throw;
            }


        }

        /// <summary>
        /// This method will be called by the plugin engine after all plugins have executed 
        /// </summary>
        public void Dispose()
        {
            // We don't need a cleanup
        }

       

        #region Private methods
        /// <summary>
        /// Retrieves the value with the specified key from the Items collection of the context. 
        /// </summary>
        /// <typeparam name="T">Type to return</typeparam>
        /// <param name="context">Post process context</param>
        /// <param name="key">key</param>
        /// <returns>collection value</returns>
        private T GetItemValue<T>(IPublishPostProcessContext context, string key)
        {
            object value;
            if (!context.Items.TryGetValue(key, out value))
            {
                throw new InvalidOperationException($"Items does not contain key '{key}'");
            }
            T valueConverted = default(T);
            try
            {
                valueConverted = (T)value;
            }
            catch (InvalidCastException)
            {
                throw new InvalidOperationException($"Items value with the key '{key}' has incorrect type.");
            }
            return valueConverted;
        }

        
        #endregion
    }
}
