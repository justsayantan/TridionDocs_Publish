﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Trisoft.InfoShare.Plugins.SDK;

namespace $safeprojectname$.Helpers
{
    class Logger
    {
        private IEventMonitor _eventMonitor = null;
        private long _progressId = 0;
        private ILogService _logService = null;

        public Logger(IEventMonitor eventMonitor, long progressId, ILogService logService)
        {
            _eventMonitor = eventMonitor;
            _progressId = progressId;
            _logService = logService;
        }

        public Logger(ILogService logService)
        {
            _logService = logService;
        }


        public void writeInfo(string action, string description)
        {
            if (_eventMonitor != null)
                _eventMonitor.AddEventDetail(_progressId, EventLevel.Information, action, description, DetailStatus.Success);

            _logService.Info("{0} - {1}", action, description);
        }

        public void writeInfo(string action, string description, EventDataType datatype, string data)
        {
            if (_eventMonitor != null)
                _eventMonitor.AddEventDetail(_progressId, EventLevel.Information, action, description, DetailStatus.Success, datatype, data);

            _logService.Info("{0} - {1}", action, description);
        }


        public void writeVerbose(string action, string description)
        {
            if (_eventMonitor != null)
                _eventMonitor.AddEventDetail(_progressId, EventLevel.Verbose, action, description, DetailStatus.Success);

            _logService.Info("{0} - {1}", action, description);
        }

        public void writeVerbose(string action, string description, EventDataType datatype, string data)
        {
            if (_eventMonitor != null)
                _eventMonitor.AddEventDetail(_progressId, EventLevel.Verbose, action, description, DetailStatus.Success, datatype, data);

            _logService.Info("{0} - {1}", action, description);
        }

        public void writeDebug(string action, string description)
        {
            if (_eventMonitor != null)
                _eventMonitor.AddEventDetail(_progressId, EventLevel.Debug, action, description, DetailStatus.Success);

            _logService.Debug("{0} - {1}", action, description);
        }

        public void writeDebug(string action, string description, EventDataType datatype, string data)
        {
            if (_eventMonitor != null)
                _eventMonitor.AddEventDetail(_progressId, EventLevel.Debug, action, description, DetailStatus.Success, datatype, data);

            _logService.Debug("{0} - {1}", action, description);
        }

        public void writeWarning(string action, string description)
        {
            if (_eventMonitor != null)
                _eventMonitor.AddEventDetail(_progressId, EventLevel.Warning, action, description, DetailStatus.Success);

            _logService.Warn("{0} - {1}", action, description);
        }

        public void writeWarning(string action, string description, EventDataType datatype, string data)
        {
            if (_eventMonitor != null)
                _eventMonitor.AddEventDetail(_progressId, EventLevel.Warning, action, description, DetailStatus.Success, datatype, data);

            _logService.Warn("{0} - {1}", action, description);
        }
        public void writeException(string action, string description, Exception exception)
        {
            if (_eventMonitor != null)
                _eventMonitor.AddEventDetail(_progressId, EventLevel.Exception, action, description, DetailStatus.Failed);

            _logService.ErrorException(string.Format("{0} - {1}", action, description), exception);
        }

        public void writeException(string action, string description, EventDataType datatype, string data, Exception exception)
        {
            if (_eventMonitor != null)
                _eventMonitor.AddEventDetail(_progressId, EventLevel.Exception, action, description, DetailStatus.Failed, datatype, data);

            _logService.ErrorException(string.Format("{0} - {1}", action, description), exception);
        }
    }
}
